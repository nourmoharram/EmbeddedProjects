/*
 * Port_priv.h
 *
 *  Created on: Feb 17, 2023
 *      Author: aya_enan
 */

#ifndef PORT_PORT_PRIV_H_
#define PORT_PORT_PRIV_H_


/******************************************
  Local Functions Prototypes
*******************************************/

/******************************************
  Local Macros / Functions
*******************************************/
#endif /* PORT_PORT_PRIV_H_ */
