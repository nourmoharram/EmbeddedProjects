/*
 * Dio_priv.h
 *
 *  Created on: Feb 17, 2023
 *      Author: aya_enan
 */

#ifndef DIO_DIO_PRIV_H_
#define DIO_DIO_PRIV_H_



/******************************************
  Local Macros / Functions
*******************************************/

/******************************************
  Local Functions Prototypes
*******************************************/
#endif /* DIO_DIO_PRIV_H_ */
