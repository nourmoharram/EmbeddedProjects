/*
 * ADC_Private.h
 *
 *  Created on: Feb 26, 2023
 *      Author: Dell
 */

#ifndef MCAL_ADC_ADC_PRIVATE_H_
#define MCAL_ADC_ADC_PRIVATE_H_

#define MAX_DELAY     50000

#endif /* MCAL_ADC_ADC_PRIVATE_H_ */
